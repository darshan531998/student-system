package com.studentapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.studentapp.entite.Studentmarks;


@Controller
public class Studentcontroller {
	
	@GetMapping("/index")
	public String viewfrom(Model model)
	{
		model.addAttribute("studentmarks", new Studentmarks());
	     return "index";
	}
	
	@PostMapping("/data")
	public String studentavg(@ModelAttribute Studentmarks studentmarks, BindingResult result, Model model)
	{
		model.addAttribute("studentmarks", studentmarks);
		return "calculate";
	}


}
