package com.studentapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Studentmanagesystemapp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
