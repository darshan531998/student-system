package com.studentapp.entite;

public class Studentmarks {
	
	private String studentname;
	private int sem1;
	private int sem2;
	private int sub1;
	private int sub2;
	private int sub3;
	public String getStudentname() {
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public int getSem1() {
		return sem1;
	}
	public void setSem1(int sem1) {
		this.sem1 = sem1;
	}
	public int getSem2() {
		return sem2;
	}
	public void setSem2(int sem2) {
		this.sem2 = sem2;
	}
	public int getSub1() {
		return sub1;
	}
	public void setSub1(int sub1) {
		this.sub1 = sub1;
	}
	public int getSub2() {
		return sub2;
	}
	public void setSub2(int sub2) {
		this.sub2 = sub2;
	}
	public int getSub3() {
		return sub3;
	}
	public void setSub3(int sub3) {
		this.sub3 = sub3;
	}
	
	public String name()
	{
		return studentname;
	}
	public String stmnt()
	{
		return "The avg marks is";
	}
	
	
	public int avg()
	{
		
		return ((sub1+sub2+sub3)/3);
	}
	
	public long percentage()
	{
		return ((sub1+sub2+sub3)/300*100);
	}
	
	

}
