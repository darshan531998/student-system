package com.studentapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Studentmanagesystemapp1Application {

	public static void main(String[] args) {
		SpringApplication.run(Studentmanagesystemapp1Application.class, args);
	}

}
